# Legends of Aeron - actualizador. Descarga la ultima version del juego desde GitHub y la abre.
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$repo = 'todounmundo420-sys/LegendsOfAeron-Releases'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$game = Join-Path $root 'Juego'
$verFile = Join-Path $game 'version.txt'

function Find-Exe($dir) {
    Get-ChildItem -Path $dir -Filter *.exe -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -notlike 'UnityCrashHandler*' } | Select-Object -First 1
}

try {
    Write-Host '=== Legends of Aeron ===' -ForegroundColor Cyan

    $installed = ''
    if (Test-Path $verFile) { $installed = (Get-Content $verFile -Raw).Trim() }

    # 1) Preguntar a GitHub cual es la ultima version
    $rel = $null
    try {
        Write-Host 'Buscando actualizaciones...'
        $rel = Invoke-RestMethod -Uri ('https://api.github.com/repos/' + $repo + '/releases/latest') -Headers @{ 'User-Agent' = 'LegendsLauncher' } -TimeoutSec 20
    } catch {
        Write-Host 'No pude consultar las actualizaciones (sin internet o aun no hay version publicada).' -ForegroundColor Yellow
    }

    # 2) Si hay una version distinta, descargarla e instalarla
    if ($rel -ne $null) {
        $tag = [string]$rel.tag_name
        $asset = @($rel.assets | Where-Object { $_.name -like '*.zip' })[0]

        if ($asset -eq $null) {
            Write-Host 'La version publicada no tiene el archivo .zip del juego.' -ForegroundColor Yellow
        }
        elseif ($tag -ne $installed) {
            $had = 'ninguna'
            if ($installed -ne '') { $had = $installed }
            Write-Host ('Version nueva: ' + $tag + '   (tienes: ' + $had + ')') -ForegroundColor Green

            $tmp = Join-Path $env:TEMP 'LegendsUpdate'
            if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
            New-Item -ItemType Directory -Path $tmp | Out-Null
            $zip = Join-Path $tmp 'juego.zip'

            Write-Host 'Descargando... (puede tardar unos minutos)'
            & curl.exe -L --fail --progress-bar -o $zip $asset.browser_download_url
            if ($LASTEXITCODE -ne 0) { throw 'La descarga fallo. Revisa tu internet y vuelve a intentarlo.' }

            Write-Host 'Instalando...'
            $ex = Join-Path $tmp 'x'
            Expand-Archive -Path $zip -DestinationPath $ex -Force

            $src = $ex
            if (-not (Find-Exe $src)) {
                $subs = @(Get-ChildItem -Path $src -Directory)
                if ($subs.Count -eq 1) { $src = $subs[0].FullName }
            }
            if (-not (Find-Exe $src)) { throw 'El archivo descargado no tiene el juego dentro (falta el .exe).' }

            if (Test-Path $game) { Remove-Item $game -Recurse -Force }
            Move-Item -Path $src -Destination $game
            Set-Content -Path $verFile -Value $tag -Encoding ASCII
            Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
            Write-Host 'Listo, juego actualizado.' -ForegroundColor Green
        }
        else {
            Write-Host ('Ya tienes la ultima version (' + $tag + ').') -ForegroundColor Green
        }
    }

    # 3) Abrir el juego
    $exe = Find-Exe $game
    if (-not $exe) { throw 'No hay ninguna version del juego instalada todavia. Conectate a internet y abre Jugar.bat otra vez.' }
    Write-Host 'Abriendo el juego...'
    Start-Process -FilePath $exe.FullName -WorkingDirectory $game
    Start-Sleep -Seconds 2
}
catch {
    Write-Host ''
    Write-Host ('Error: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}